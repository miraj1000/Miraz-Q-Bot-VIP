
if (chrome.proxy) {
    console.log("Proxi ok")
  } else {
    console.log("Proxi no")
  }




// popup.js

let proxyEnabled = false;

// Функция переключения прокси
function toggleProxy() {

  if (proxyEnabled) {
    // Отключаем прокси
    chrome.proxy.settings.set({mode: 'direct'});
    console.log("прокси выключил");
  } else {
    // Включаем прокси
    chrome.proxy.settings.set({
      mode: 'fixed_servers',
      rules: {
        singleProxy: {
          scheme: 'http',
          host: '85.237.204.177',
          port: 8385,
          username: 'user49467', 
          password: 'v7qdsf'
        }  
      }
    });
    console.log("прокси включил")}

  proxyEnabled = !proxyEnabled;

}

// Повесить обработчик на кнопку
document.getElementById("toggleProxy").addEventListener("click", toggleProxy.bind(this));